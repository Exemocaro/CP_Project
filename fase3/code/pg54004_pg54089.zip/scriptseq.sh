#!/bin/bash
time ./MDseq.exe < inputdata.txt
